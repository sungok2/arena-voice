# Arena Voice - Android WebView (Galaxy S20)

실제 arena.ai를 앱으로 감싸서 음성 입력/출력을 추가한 네이티브 앱입니다.

## 기능
- arena.ai Agent Mode 전체 기능 사용
- 하드웨어 마이크 버튼으로 한국어 음성 인식
- 답변 자동 TTS 읽기
- 로그인 상태 유지
- 이전 대화 기록 (Arena 서버에 저장)

## 빌드 방법 (5분)
1. Android Studio 설치
2. New Project > Empty Views Activity
3. package name: com.arena.voice
4. 이 폴더의 MainActivity.kt를 복사
5. AndroidManifest.xml에 추가:
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<application android:usesCleartextTraffic="true" ...>
```
6. Build > Build APK
7. Galaxy S20에 설치

## 사용법
- 앱 실행 → arena.ai 로그인
- 화면 아래 플로팅 마이크 버튼 터치 (웹페이지에 자동 주입됨)
- 말하기 → 자동으로 입력창에 들어가고 전송됨
- 답변을 자동으로 읽어줌

이 버전은 실제 Arena Agent Mode를 사용하므로 API 키 불필요.