package com.arena.voice

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var micButton: ImageButton
    private var isListening = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastSpokenText = ""

    @SuppressLint("SetJavaScriptEnabled", "WakelockTimeout")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // 권한 체크
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
        
        // 화면 꺼짐 방지
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "ArenaVoice::WakeLock")
        
        val layout = FrameLayout(this)
        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        
        // WebView 최적화 (갤럭시 S20)
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            userAgentString = "$userAgentString ArenaVoice/1.1 (Galaxy S20)"
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        
        // 쿠키 유지 - 로그인 기억
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
            flush()
        }
        
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectResponseObserver()
                // 페이지 로드 후 2초 뒤 안내
                view?.postDelayed({
                    if (url?.contains("arena.ai") == true) {
                        Toast.makeText(this@MainActivity, "로그인 후 하단 마이크를 눌러 말하세요", Toast.LENGTH_SHORT).show()
                    }
                }, 2000)
            }
            
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                Toast.makeText(this@MainActivity, "로딩 오류: 인터넷 연결 확인", Toast.LENGTH_SHORT).show()
            }
        }
        
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(VoiceBridge(), "ArenaVoice")
        
        layout.addView(webView)
        
        // 플로팅 마이크 버튼 - 갤럭시 S20 하단 최적화
        micButton = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now)
            setBackgroundResource(android.R.drawable.btn_default)
            alpha = 0.9f
            scaleType = ImageButton.ScaleType.CENTER_INSIDE
            setPadding(24, 24, 24, 24)
            setOnClickListener { toggleVoice() }
            setOnLongClickListener { 
                Toast.makeText(context, "길게 눌러 연속 대화 (준비중)", Toast.LENGTH_SHORT).show()
                true
            }
        }
        
        val btnSize = (72 * resources.displayMetrics.density).toInt()
        val params = FrameLayout.LayoutParams(btnSize, btnSize).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            bottomMargin = (100 * resources.displayMetrics.density).toInt()
            rightMargin = (24 * resources.displayMetrics.density).toInt()
        }
        layout.addView(micButton, params)
        setContentView(layout)
        
        // Arena 로드
        webView.loadUrl("https://arena.ai")
        
        tts = TextToSpeech(this, this)
        setupSpeechRecognizer()
    }

    private fun setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "음성인식을 지원하지 않는 기기입니다", Toast.LENGTH_LONG).show()
            return
        }
        
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
                runOnUiThread {
                    micButton.setColorFilter(0xFFFF4444.toInt())
                    micButton.alpha = 1f
                    wakeLock?.acquire(10*60*1000L)
                }
            }
            
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()
                if (!text.isNullOrBlank()) {
                    injectTextToArena(text)
                }
                finishListening()
            }
            
            override fun onError(error: Int) {
                finishListening()
                val msg = when(error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "음성을 인식하지 못했습니다"
                    SpeechRecognizer.ERROR_NETWORK -> "네트워크 오류"
                    else -> "다시 시도해주세요"
                }
                if (error != SpeechRecognizer.ERROR_CLIENT) {
                    Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                }
            }
            
            override fun onEndOfSpeech() { finishListening() }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                // 음량에 따라 버튼 크기 조절 (시각 피드백)
                val scale = 1f + (rmsdB / 20f).coerceIn(0f, 0.2f)
                micButton.scaleX = scale
                micButton.scaleY = scale
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }
    
    private fun finishListening() {
        isListening = false
        runOnUiThread {
            micButton.clearColorFilter()
            micButton.alpha = 0.9f
            micButton.scaleX = 1f
            micButton.scaleY = 1f
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
    }

    private fun toggleVoice() {
        if (isListening) {
            speechRecognizer.stopListening()
        } else {
            val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            try {
                speechRecognizer.startListening(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "음성인식 시작 실패", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun injectTextToArena(text: String) {
        // 하자 보수 #1: 특수문자 이스케이프 강화
        val safeText = text.replace("\\", "\\\\").replace("'", "\\'").replace("\"", "\\\"").replace("\n", "\\n")
        
        // 하자 보수 #2: Arena 실제 DOM 구조 대응 (2024 기준)
        val js = """
            (function() {
                // 다양한 입력창 시도
                const selectors = [
                    'textarea[data-id="root"]',
                    'textarea[placeholder]',
                    'div[contenteditable="true"][role="textbox"]',
                    '#prompt-textarea',
                    'textarea'
                ];
                
                let input = null;
                for (const s of selectors) {
                    const el = document.querySelector(s);
                    if (el && el.offsetParent !== null) { input = el; break; }
                }
                
                if (!input) {
                    return 'NOT_FOUND';
                }
                
                input.focus();
                input.click();
                
                // React/Vue 대응
                const nativeSetter = Object.getOwnPropertyDescriptor(
                    window.HTMLTextAreaElement.prototype, 'value'
                )?.set;
                
                if (input.tagName === 'TEXTAREA' || input.tagName === 'INPUT') {
                    if (nativeSetter) nativeSetter.call(input, '$safeText');
                    else input.value = '$safeText';
                } else {
                    input.textContent = '$safeText';
                    input.innerText = '$safeText';
                }
                
                // 이벤트 발생
                ['input', 'change', 'keyup'].forEach(type => {
                    input.dispatchEvent(new Event(type, {bubbles: true, cancelable: true}));
                });
                
                // 전송 버튼 찾기 및 클릭
                setTimeout(() => {
                    const sendSelectors = [
                        'button[data-testid="send-button"]',
                        'button[aria-label*="Send"]',
                        'button:has(svg)',
                        'form button[type="submit"]'
                    ];
                    for (const s of sendSelectors) {
                        try {
                            const btn = document.querySelector(s);
                            if (btn && !btn.disabled && btn.offsetParent) {
                                btn.click();
                                return 'SENT';
                            }
                        } catch(e) {}
                    }
                    return 'TYPED';
                }, 150);
                
                return 'OK';
            })();
        """.trimIndent()
        
        webView.evaluateJavascript(js) { result ->
            runOnUiThread {
                when {
                    result.contains("NOT_FOUND") -> Toast.makeText(this, "입력창을 찾을 수 없습니다. 페이지를 새로고침 해주세요", Toast.LENGTH_LONG).show()
                    else -> Toast.makeText(this, "전송: $text", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // 하자 보수 #3: 답변 자동 읽기 기능 복구
    private fun injectResponseObserver() {
        val observerJs = """
            (function() {
                if (window.arenaObserver) return;
                
                let lastText = '';
                window.arenaObserver = new MutationObserver(() => {
                    // Arena 응답 감지
                    const messages = document.querySelectorAll(
                        '[data-message-author-role="assistant"], .group\\/assistant, [class*="assistant"]'
                    );
                    
                    if (messages.length > 0) {
                        const last = messages[messages.length - 1];
                        const text = (last.innerText || last.textContent || '').trim();
                        
                        if (text && text !== lastText && text.length > 5 && !text.includes('...')) {
                            // 완전한 문장일 때만
                            if (/[.!?。！？]$/.test(text) || text.length > 50) {
                                lastText = text;
                                if (window.ArenaVoice) {
                                    window.ArenaVoice.onResponse(text.substring(0, 500));
                                }
                            }
                        }
                    }
                });
                
                window.arenaObserver.observe(document.body, {
                    childList: true,
                    subtree: true,
                    characterData: true
                });
            })();
        """.trimIndent()
        webView.evaluateJavascript(observerJs, null)
    }

    inner class VoiceBridge {
        @JavascriptInterface
        fun onResponse(text: String) {
            // 하자 보수 #4: 중복 읽기 방지
            if (text == lastSpokenText || text.length < 3) return
            lastSpokenText = text
            
            runOnUiThread {
                if (::tts.isInitialized) {
                    tts.stop()
                    // 긴 텍스트는 첫 문장만
                    val speakText = text.split(Regex("[.!?。]")).firstOrNull()?.take(200) ?: text.take(200)
                    tts.speak(speakText, TextToSpeech.QUEUE_FLUSH, null, "arena")
                }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.KOREAN
            tts.setSpeechRate(1.05f) // 약간 빠르게
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    wakeLock?.acquire(60000)
                }
                override fun onDone(utteranceId: String?) {
                    if (wakeLock?.isHeld == true) wakeLock?.release()
                }
                override fun onError(utteranceId: String?) {}
            })
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "마이크 권한이 필요합니다", Toast.LENGTH_LONG).show()
        }
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        speechRecognizer.destroy()
        tts.shutdown()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        super.onDestroy()
    }
}